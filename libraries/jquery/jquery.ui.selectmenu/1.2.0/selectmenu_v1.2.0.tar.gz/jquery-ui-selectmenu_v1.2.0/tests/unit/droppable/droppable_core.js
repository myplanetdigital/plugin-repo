/*
 * droppable_core.js
 */

var el, drg;

(function($) {

module("droppable: core");

})(jQuery);
