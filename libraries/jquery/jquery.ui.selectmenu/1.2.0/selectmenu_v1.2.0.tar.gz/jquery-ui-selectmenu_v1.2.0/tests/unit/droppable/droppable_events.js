/*
 * droppable_events.js
 */
(function($) {

module("droppable: events");

})(jQuery);
